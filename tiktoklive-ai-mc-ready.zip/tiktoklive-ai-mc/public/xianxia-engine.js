class XianxiaEngine {
  constructor() {
    this.recentLines = [];
    this.maxMemory = 12;
    this.welcomeTemplates = [
      "Xin chào đạo hữu {user}, hoan nghênh đạo hữu đến với buổi tu luyện hôm nay!",
      "Đạo hữu {user} vừa bước vào tiên môn, xin mời an tọa đàm đạo!",
      "Linh khí dâng trào, chào mừng đạo hữu {user} đã ghé thăm đạo tràng!",
      "Tông môn thêm phần rạng rỡ khi có đạo hữu {user}, mời dùng trà linh!",
      "Hoan nghênh đạo hữu {user} nhập tịch môn hạ, chúc đạo hữu sớm ngộ đại đạo!"
    ];
    this.giftTemplates = [
      "Đa tạ đạo hữu {user} đã tặng {gift}! Chúc đạo hữu tu vi tăng tiến!",
      "Đa tạ đạo hữu {user} đã góp linh lực với {gift} cho tông môn!",
      "Thật cảm kích tấm lòng của đạo hữu {user} cùng {gift}, chúc cảnh giới đột phá!",
      "Linh bảo {gift} từ đạo hữu {user} thật phi phàm, chúc phi thăng thuận lợi!"
    ];
    this.bigGiftTemplates = [
      "Xin chúc mừng đạo hữu {user} đã gửi đại lễ {gift}! Đa tạ đạo hữu trợ tông môn!",
      "Chấn động thiên địa! Đạo hữu {user} vừa ban đại lễ {gift}, bái tạ Lão Tổ!",
      "Đại lễ {gift} giáng thế từ đạo hữu {user}! Chúc đạo hữu sớm bước vào Tiên Tôn!"
    ];
    this.chatTemplates = [
      "Đạo hữu {user} nói rất có lý, lời này ẩn chứa đạo vận sâu xa!",
      "Nghe đạo hữu {user} chia sẻ mà tại hạ thấy tâm cảnh khai mở!",
      "Đạo hữu {user} thật là cao nhân ẩn thế, mời tiếp tục chỉ giáo!"
    ];
  }
  pick(pool) {
    const choices = pool.filter(x => !this.recentLines.includes(x));
    const chosen = (choices.length ? choices : pool)[Math.floor(Math.random() * (choices.length ? choices : pool).length)];
    this.recentLines.push(chosen);
    if (this.recentLines.length > this.maxMemory) this.recentLines.shift();
    return chosen;
  }
  format(template, { user, gift, count = 1 }) {
    const giftLabel = count > 1 ? `${count} ${gift || 'Linh Bảo'}` : (gift || 'Linh Bảo');
    return template.replace(/\{user\}/g, user || 'vô danh đạo hữu').replace(/\{gift\}/g, giftLabel);
  }
  async generateSpeech({ type, user, gift, count = 1, comment = '', isBigGift = false, customWelcome = '', customThanks = '' }) {
    if (type === 'join') {
      if (customWelcome.trim()) return this.format(customWelcome, { user });
      return await this.tryAI({ eventType: 'join', userName: user }) || this.format(this.pick(this.welcomeTemplates), { user });
    }
    if (type === 'gift') {
      if (customThanks.trim() && !isBigGift) return this.format(customThanks, { user, gift, count });
      return await this.tryAI({ eventType: 'gift', userName: user, giftName: gift, giftCount: count }) ||
        this.format(this.pick(isBigGift ? this.bigGiftTemplates : this.giftTemplates), { user, gift, count });
    }
    if (type === 'chat') {
      return await this.tryAI({ eventType: 'chat', userName: user, commentText: comment }) ||
        this.format(this.pick(this.chatTemplates), { user });
    }
    return `Xin chào đạo hữu ${user || ''}!`;
  }
  async tryAI(payload) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 9000);
    try {
      const response = await fetch('/api/ai-comment', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload), signal: controller.signal
      });
      if (!response.ok) return null;
      const data = await response.json();
      return !data.useLocalEngine && data.text ? data.text : null;
    } catch (_) { return null; }
    finally { clearTimeout(timer); }
  }
}
