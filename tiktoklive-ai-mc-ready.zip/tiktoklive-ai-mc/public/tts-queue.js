class VietnameseTTSQueue {
  constructor(onStateChange) {
    this.queue = [];
    this.pendingJoins = [];
    this.joinTimer = null;
    this.isSpeaking = false;
    this.isPaused = false;
    this.enabled = true;
    this.onStateChange = onStateChange || (() => {});
    this.currentAudio = null;
    this.settings = { gender: 'female-north', engine: 'hybrid', rate: 1, pitch: 1, volume: 1, delaySeconds: 1.5 };
  }
  updateSettings(partial) { this.settings = { ...this.settings, ...partial }; }
  setEnabled(value) {
    this.enabled = Boolean(value);
    if (!this.enabled) this.clearQueue();
    this.emit();
  }
  togglePause() {
    this.isPaused = !this.isPaused;
    if (this.isPaused) {
      if (window.speechSynthesis) window.speechSynthesis.cancel();
      if (this.currentAudio) this.currentAudio.pause();
    } else {
      if (this.currentAudio?.paused && this.currentAudio.src) this.currentAudio.play().catch(() => {});
      this.processNext();
    }
    this.emit();
    return this.isPaused;
  }
  clearQueue() {
    this.queue = []; this.pendingJoins = [];
    if (this.joinTimer) clearTimeout(this.joinTimer);
    this.joinTimer = null;
    if (window.speechSynthesis) window.speechSynthesis.cancel();
    if (this.currentAudio) { this.currentAudio.pause(); this.currentAudio = null; }
    this.isSpeaking = false; this.emit();
  }
  enqueueJoin(name, speech) {
    if (!this.enabled) return;
    this.pendingJoins.push({ name, speech });
    if (!this.joinTimer) {
      this.joinTimer = setTimeout(() => {
        const batch = this.pendingJoins.splice(0);
        this.joinTimer = null;
        if (batch.length === 1) this.enqueue(batch[0].speech);
        else if (batch.length > 1) {
          const names = batch.slice(0, 4).map(x => x.name).join(', ');
          const extra = batch.length > 4 ? ` cùng ${batch.length - 4} đạo hữu khác` : '';
          this.enqueue(`Hoan nghênh các đạo hữu ${names}${extra} đã bước vào buổi tu luyện!`);
        }
      }, 1800);
    }
    this.emit();
  }
  enqueue(text, highPriority = false) {
    if (!this.enabled || !text) return;
    const item = { text: String(text).slice(0, 500) };
    if (highPriority) this.queue.unshift(item); else this.queue.push(item);
    this.emit(); this.processNext();
  }
  emit() {
    this.onStateChange({
      queueLength: this.queue.length + this.pendingJoins.length,
      isSpeaking: this.isSpeaking, isPaused: this.isPaused, enabled: this.enabled
    });
  }
  async processNext() {
    if (this.isSpeaking || this.isPaused || !this.enabled || !this.queue.length) { this.emit(); return; }
    const item = this.queue.shift();
    this.isSpeaking = true; this.emit();
    try { await this.speakText(item.text); } catch (err) { console.warn('TTS:', err); }
    await new Promise(resolve => setTimeout(resolve, Math.max(300, this.settings.delaySeconds * 1000)));
    this.isSpeaking = false; this.emit(); this.processNext();
  }
  pickVoice() {
    if (!window.speechSynthesis) return null;
    const voices = window.speechSynthesis.getVoices() || [];
    const vi = voices.filter(v => (v.lang || '').toLowerCase().startsWith('vi'));
    if (!vi.length) return null;
    const wantMale = this.settings.gender === 'male-warm';
    return vi.find(v => wantMale ? /male|nam/i.test(v.name) : /female|nữ|nu|linh/i.test(v.name)) || vi[0];
  }
  speakBrowser(text) {
    return new Promise((resolve, reject) => {
      if (!window.speechSynthesis) return reject(new Error('Thiết bị không hỗ trợ Web Speech'));
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'vi-VN'; utterance.voice = this.pickVoice();
      utterance.rate = this.settings.rate; utterance.pitch = this.settings.pitch;
      utterance.volume = this.settings.volume;
      utterance.onend = resolve; utterance.onerror = reject;
      window.speechSynthesis.speak(utterance);
    });
  }
  speakServer(text) {
    return new Promise((resolve, reject) => {
      const audio = new Audio(`/api/tts?text=${encodeURIComponent(text)}`);
      this.currentAudio = audio; audio.volume = this.settings.volume;
      audio.playbackRate = Math.min(1.35, Math.max(.75, this.settings.rate));
      audio.onended = () => { this.currentAudio = null; resolve(); };
      audio.onerror = () => { this.currentAudio = null; reject(new Error('Không phát được âm thanh Server')); };
      audio.play().catch(reject);
    });
  }
  async speakText(text) {
    if (this.settings.engine === 'browser') return this.speakBrowser(text);
    if (this.settings.engine === 'server') return this.speakServer(text);
    try { await this.speakServer(text); } catch (_) { await this.speakBrowser(text); }
  }
}
