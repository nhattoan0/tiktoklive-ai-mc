const socket = io();
const engine = new XianxiaEngine();
const leaderboard = new Map();
let demoInterval = null;
let demoCounter = 0;
const $ = id => document.getElementById(id);

const tts = new VietnameseTTSQueue(state => {
  $('queueCount').textContent = state.queueLength;
  $('speakingNow').textContent = !state.enabled ? 'Trạng thái: MC đã tắt' :
    state.isPaused ? 'Trạng thái: Đang tạm dừng' :
    state.isSpeaking ? 'Trạng thái: Đang đọc...' : 'Trạng thái: Nhàn rỗi';
});

function timeNow() { return new Date().toLocaleTimeString('vi-VN', { hour12: false }); }

// Dùng textContent cho dữ liệu từ TikTok, không chèn nickname/comment vào innerHTML.
function addItem(listId, parts, extraClass = '') {
  const li = document.createElement('li');
  li.className = `event-item ${extraClass}`.trim();
  for (const part of parts) {
    if (part.strong) {
      const strong = document.createElement('strong');
      strong.textContent = part.text;
      li.append(strong);
    } else li.append(document.createTextNode(part.text));
  }
  const meta = document.createElement('div');
  meta.className = 'event-meta'; meta.textContent = timeNow(); li.append(meta);
  const list = $(listId); list.prepend(li);
  while (list.children.length > 40) list.lastElementChild.remove();
}
function addHistory(text, tag) {
  const li = document.createElement('li'); li.className = 'history-item';
  const strong = document.createElement('strong'); strong.textContent = `[${tag}] `;
  li.append(strong, document.createTextNode(text));
  const meta = document.createElement('div'); meta.className = 'event-meta'; meta.textContent = timeNow();
  li.append(meta); $('historyList').prepend(li);
  while ($('historyList').children.length > 60) $('historyList').lastElementChild.remove();
}
function renderLeaderboard() {
  const list = $('leaderboardList'); list.replaceChildren();
  [...leaderboard.entries()].sort((a,b) => b[1]-a[1]).slice(0,10).forEach(([name, score], index) => {
    const li = document.createElement('li'); li.className = `event-item ${index === 0 ? 'big-gift' : ''}`;
    li.textContent = `#${index + 1} ${name} — ${score} kim cương`; list.append(li);
  });
}
async function handleLiveEvent(ev) {
  const name = String(ev.nickname || 'Đạo hữu').slice(0, 60);
  if (ev.type === 'join') {
    addItem('joinList', [{text:name, strong:true},{text:' vừa bước vào phòng'}]);
    if (!$('optWelcome').checked) return;
    const speech = await engine.generateSpeech({ type:'join', user:name, customWelcome:$('customWelcome').value });
    addHistory(speech, 'Chào đạo hữu'); tts.enqueueJoin(name, speech);
  } else if (ev.type === 'gift') {
    const gift = String(ev.giftName || 'Linh Bảo').slice(0,60);
    const count = Math.max(1, Number(ev.giftCount) || 1);
    const score = Math.max(0, Number(ev.diamondValue) || count);
    const isBig = score >= (Number($('bigGiftThreshold').value) || 100);
    leaderboard.set(name, (leaderboard.get(name) || 0) + score); renderLeaderboard();
    addItem('giftList', [{text:name,strong:true},{text:` tặng ${count}x `},{text:gift,strong:true},{text:` (${score} điểm)`}], isBig ? 'big-gift' : '');
    if (!$('optGift').checked) return;
    const speech = await engine.generateSpeech({
      type:'gift', user:name, gift, count, isBigGift:isBig, customThanks:$('customThanks').value
    });
    addHistory(speech, isBig ? 'Đại lễ ưu tiên' : 'Tạ quà');
    tts.enqueue(speech, isBig && $('optPriorityBigGift').checked);
  } else if (ev.type === 'chat') {
    const comment = String(ev.comment || '').slice(0,300);
    addItem('joinList', [{text:`💬 ${name}: ${comment}`}]);
    if (!$('optChat').checked) return;
    const speech = await engine.generateSpeech({ type:'chat', user:name, comment });
    addHistory(speech, 'Đáp chat'); tts.enqueue(speech);
  }
}

socket.on('connect', () => { $('statusMessage').textContent = 'Đã kết nối máy chủ. Có thể chạy DEMO hoặc nhập username TikTok.'; });
socket.on('connect_error', () => { $('statusMessage').textContent = 'Không kết nối được máy chủ. Hãy tải lại trang.'; });
socket.on('tiktok-status', data => {
  $('statusMessage').textContent = data.message;
  const badge = $('statusBadge'); badge.className = 'badge';
  if (data.status === 'connected') { badge.classList.add('badge-live'); badge.textContent = 'Đã kết nối'; }
  else if (data.status === 'connecting') { badge.classList.add('badge-connecting'); badge.textContent = 'Đang kết nối'; }
  else { badge.classList.add('badge-idle'); badge.textContent = 'Chưa kết nối'; }
});
socket.on('tiktok-error', message => {
  $('statusMessage').textContent = message;
  $('statusBadge').className = 'badge badge-error'; $('statusBadge').textContent = 'Lỗi kết nối';
});
socket.on('live-event', ev => { handleLiveEvent(ev).catch(err => console.error(err)); });

$('btnConnect').addEventListener('click', () => socket.emit('connect-tiktok', $('tiktokUsername').value));
$('tiktokUsername').addEventListener('keydown', e => { if (e.key === 'Enter') $('btnConnect').click(); });
$('btnDisconnect').addEventListener('click', () => socket.emit('disconnect-tiktok'));

$('btnToggleMC').addEventListener('click', e => {
  const enabled = !tts.enabled; tts.setEnabled(enabled);
  e.currentTarget.textContent = enabled ? 'MC AI: ĐANG BẬT' : 'MC AI: ĐÃ TẮT';
});
$('btnPauseTTS').addEventListener('click', e => {
  e.currentTarget.textContent = tts.togglePause() ? 'Tiếp tục đọc' : 'Tạm dừng đọc';
});
$('btnTestVoice').addEventListener('click', () => {
  const gender = $('voiceGender').value === 'male-warm' ? 'giọng nam trầm ấm' : 'giọng nữ tiếng Việt';
  const text = `Kiểm tra thành công ${gender}. Chúc đạo hữu tu vi tinh tiến, livestream hồng phát!`;
  addHistory(text, 'Kiểm tra'); tts.enqueue(text, true);
});
$('btnClearHistory').addEventListener('click', () => {
  ['joinList','giftList','leaderboardList','historyList'].forEach(id => $(id).replaceChildren());
  leaderboard.clear(); tts.clearQueue();
});

function syncVoiceSettings() {
  const rate = Number($('voiceRate').value), pitch = Number($('voicePitch').value);
  const volume = Number($('voiceVolume').value), delaySeconds = Number($('delayBetweenSpeech').value);
  $('rateVal').textContent = `${rate.toFixed(2)}x`; $('pitchVal').textContent = pitch.toFixed(2);
  $('volumeVal').textContent = `${Math.round(volume*100)}%`; $('delayVal').textContent = `${delaySeconds.toFixed(1)}s`;
  tts.updateSettings({ gender:$('voiceGender').value, engine:$('voiceEngine').value, rate, pitch, volume, delaySeconds });
}
['voiceGender','voiceEngine','voiceRate','voicePitch','voiceVolume','delayBetweenSpeech'].forEach(id => {
  $(id).addEventListener('input', syncVoiceSettings); $(id).addEventListener('change', syncVoiceSettings);
});
syncVoiceSettings();

const sampleNames = ['Nguyễn Văn A','Trần Minh Khôi','Lê Tiểu Vy','Vô Danh Kiếm Khách','Hàn Lập'];
function triggerDemo(kind) {
  const name = sampleNames[demoCounter++ % sampleNames.length];
  if (kind === 'join') handleLiveEvent({type:'join',nickname:name,uniqueId:'dao_huu'});
  if (kind === 'gift') handleLiveEvent({type:'gift',nickname:name,giftName:'Hoa Hồng',giftCount:1,diamondValue:5});
  if (kind === 'bigGift') handleLiveEvent({type:'gift',nickname:name,giftName:'Cửu Thiên Huyền Đan',giftCount:1,diamondValue:250});
  if (kind === 'chat') handleLiveEvent({type:'chat',nickname:name,comment:'Hôm nay luyện đan hay luyện kiếm vậy MC?'});
}
$('btnSimJoin').addEventListener('click', () => triggerDemo('join'));
$('btnSimGift').addEventListener('click', () => triggerDemo('gift'));
$('btnSimBigGift').addEventListener('click', () => triggerDemo('bigGift'));
$('btnSimChat').addEventListener('click', () => triggerDemo('chat'));
$('btnDemoToggle').addEventListener('click', e => {
  if (demoInterval) { clearInterval(demoInterval); demoInterval = null; e.currentTarget.textContent = 'Bật Auto DEMO'; }
  else {
    e.currentTarget.textContent = 'Tắt Auto DEMO';
    demoInterval = setInterval(() => {
      const r = Math.random();
      triggerDemo(r < .45 ? 'join' : r < .75 ? 'gift' : r < .9 ? 'chat' : 'bigGift');
    }, 3500);
  }
});

// iOS Safari thường yêu cầu người dùng chạm nút trước khi phát âm thanh.
