# TikTok LIVE AI MC – Tiên Đồ Trợ Thủ

Ứng dụng Node.js + Express + Socket.IO để hiển thị sự kiện TikTok LIVE, tạo lời dẫn phong cách tiên hiệp và đọc tiếng Việt. Có chế độ DEMO không cần kết nối TikTok.

## Cấu trúc

```text
tiktoklive-ai-mc/
├── package.json
├── server.js
├── .env.example
├── .gitignore
├── README.md
└── public/
    ├── index.html
    ├── style.css
    ├── app.js
    ├── xianxia-engine.js
    └── tts-queue.js
```

## Chạy thử trên máy tính

Yêu cầu Node.js 20 trở lên.

```bash
npm install
```

Sao chép `.env.example` thành `.env`, sau đó có thể thêm Gemini API key:

```env
PORT=3000
GEMINI_API_KEY=YOUR_GEMINI_API_KEY
```

Chạy:

```bash
npm start
```

Mở `http://localhost:3000`. Nhấn các nút DEMO để thử sự kiện vào phòng, quà tặng và bình luận.

## Đưa lên GitHub

1. Giải nén ZIP.
2. Tải **các tệp bên trong thư mục dự án** lên repository GitHub, giữ nguyên thư mục `public`.
3. Không tải `.env`, `node_modules` hoặc API key lên GitHub.
4. Kiểm tra repository có `package.json`, `server.js` và thư mục `public`.

## Triển khai trên Render

Tạo **Web Service**, kết nối repository GitHub và đặt:

- Runtime: Node
- Build Command: `npm install`
- Start Command: `npm start`

Trong Environment Variables, thêm:
- `GEMINI_API_KEY` = API key Gemini của bạn (không đặt trong mã nguồn)
- `APP_ORIGIN` = URL ứng dụng Render của bạn, ví dụ `https://ten-app.onrender.com` (có thể để trống nếu chưa cần giới hạn origin)

Render tự cấp `PORT`; ứng dụng đã đọc `process.env.PORT`.

Sau khi deploy, kiểm tra `https://ten-app.onrender.com/api/health`.

## Ghi chú quan trọng

- Nếu không có `GEMINI_API_KEY`, ứng dụng tự dùng lời thoại mẫu cục bộ.
- `/api/tts` dùng endpoint Google Translate TTS không chính thức; endpoint này có thể bị giới hạn hoặc thay đổi. Chế độ Hybrid sẽ thử giọng server rồi dự phòng giọng trình duyệt.
- Chọn giọng nam/nữ chỉ là lựa chọn gần đúng theo voice mà thiết bị/trình duyệt cung cấp; không phải thiết bị nào cũng có đủ giọng tiếng Việt.
- iPhone/Safari có thể yêu cầu thao tác chạm của người dùng trước khi phát âm thanh.
- Âm thanh đang phát trên trình duyệt **không tự động được đưa vào âm thanh livestream TikTok**. Muốn khán giả nghe MC, cần định tuyến âm thanh trình duyệt/thiết bị vào nguồn phát LIVE phù hợp.
- `tiktok-live-connector` là thư viện bên thứ ba, không phải API chính thức của TikTok. Kết nối có thể thay đổi theo TikTok, khu vực, phiên LIVE hoặc phiên bản thư viện; chỉ thử với LIVE công khai mà bạn có quyền truy cập.
- Đây là bản nền tảng để thử nghiệm, chưa phải hệ thống production có xác thực người dùng, giới hạn lưu lượng, giám sát và cơ chế chống lạm dụng.

## Bảo mật

Không commit `.env`. Nếu API key từng bị đăng công khai, hãy thu hồi key cũ và tạo key mới trong Google AI Studio.
